God Weapons Rainbow - Single Resource Pack

This combines the legacy CustomModelData overrides and modern custom item definitions into ONE ZIP.
The default pack files serve legacy item-model clients. The overlay replaces/adds the modern custom item definitions for 1.21.4 through 26.2.

Minecraft 1.20.1 (pack format 15) and newer versions in the declared range may recognize the pack metadata, but this does not guarantee every intervening version renders the custom weapons correctly. Item model systems differ by version, and older-than-1.20 versions are not included/tested.

Install: place this ZIP in your resourcepacks folder and enable it.
Server note: plugin delivery config must point to this one ZIP and its SHA-1.
